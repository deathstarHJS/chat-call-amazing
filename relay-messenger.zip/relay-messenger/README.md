# Relay Messenger

A starter real-time private messenger. Includes account creation/sign-in, username search, private 1-to-1 conversations, real-time messages, online indicators, and PostgreSQL persistence.


## Deploy to Render + GitHub

1. Create a GitHub repository and upload/push this folder's contents.
2. On Render, create a **PostgreSQL** database. Copy its **Internal Database URL**.
3. Create a Render **Web Service** connected to your GitHub repo.
4. Build command: `npm install`
5. Start command: `npm start`
6. Add environment variables in Render:
   - `DATABASE_URL` = Internal Database URL from your Render PostgreSQL database
   - `SESSION_SECRET` = a long random secret (do not share it)
   - `NODE_ENV` = `production`
7. Deploy. Render provides the service URL when deployment completes.

## Run locally

- Install Node.js 20+ and PostgreSQL.
- Copy `.env.example` to `.env`, then fill `DATABASE_URL` and `SESSION_SECRET`.
- `npm install`
- `npm start`
- Open http://localhost:3000


## GitHub upload quick-start

In this folder, open a terminal:

```bash
git init
git add .
git commit -m "Initial Relay Messenger"
```
Then create a new repository on GitHub and follow the displayed instructions to add its remote and push.

## Notes

- Messages and account records persist in PostgreSQL. Do not use Render's ephemeral filesystem for database storage.
- Passwords are hashed using bcrypt.
- Session cookies are HTTP-only and SameSite=Lax. Production cookies are secure.
- This is a starter project. Before inviting real users, add stronger abuse controls, account recovery, message reporting/blocking, rate limits, moderation controls, and a privacy policy. Do not put database URLs or session secrets into GitHub.
