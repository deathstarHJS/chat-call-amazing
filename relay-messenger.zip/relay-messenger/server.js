const express = require('express');
const http = require('http');
const { Pool } = require('pg');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const bcrypt = require('bcryptjs');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes('render.com') ? { rejectUnauthorized: false } : undefined });
const sessionMiddleware = session({
  store: new PgSession({ pool, createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET || 'dev-only-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 24 * 14 }
});
app.use(express.json({ limit: '20kb' }));
app.use(sessionMiddleware);
app.use(express.static('public'));

async function initDb() {
  await pool.query(`CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY, username VARCHAR(24) UNIQUE NOT NULL, password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS conversations (
    id SERIAL PRIMARY KEY, created_at TIMESTAMPTZ DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS conversation_members (
    conversation_id INTEGER REFERENCES conversations(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    PRIMARY KEY(conversation_id, user_id)
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS messages (
    id SERIAL PRIMARY KEY, conversation_id INTEGER REFERENCES conversations(id) ON DELETE CASCADE,
    sender_id INTEGER REFERENCES users(id) ON DELETE CASCADE, body TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
  )`);
  await pool.query('CREATE INDEX IF NOT EXISTS messages_conversation_id_id_idx ON messages(conversation_id, id)');
}
const safeUser = u => ({ id: u.id, username: u.username });
const requireAuth = (req, res, next) => req.session.user ? next() : res.status(401).json({ error: 'Please sign in.' });


app.post('/api/signup', async (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!/^[a-z0-9_]{3,24}$/.test(username)) return res.status(400).json({ error: 'Username: 3–24 letters, numbers or underscores.' });
  if (password.length < 8 || password.length > 72) return res.status(400).json({ error: 'Password must be 8–72 characters.' });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query('INSERT INTO users(username,password_hash) VALUES($1,$2) RETURNING id,username', [username, hash]);
    req.session.user = safeUser(result.rows[0]);
    res.json({ user: req.session.user });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'That username is already taken.' });
    console.error(err); res.status(500).json({ error: 'Could not create account.' });
  }
});
app.post('/api/login', async (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  try {
    const result = await pool.query('SELECT id,username,password_hash FROM users WHERE username=$1', [username]);
    const u = result.rows[0];
    if (!u || !(await bcrypt.compare(password, u.password_hash))) return res.status(401).json({ error: 'Incorrect username or password.' });
    req.session.user = safeUser(u);
    res.json({ user: req.session.user });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Sign-in failed.' }); }
});
app.post('/api/logout', (req, res) => req.session.destroy(() => { res.clearCookie('connect.sid'); res.json({ ok: true }); }));
app.get('/api/me', (req, res) => res.json({ user: req.session.user || null }));
app.get('/api/people', requireAuth, async (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase().slice(0, 24);
  if (q.length < 1) return res.json({ users: [] });
  const result = await pool.query('SELECT id,username FROM users WHERE username LIKE $1 AND id<>$2 ORDER BY username LIMIT 12', [`${q}%`, req.session.user.id]);
  res.json({ users: result.rows.map(safeUser) });
});
app.get('/api/conversations', requireAuth, async (req, res) => {
  const uid = req.session.user.id;
  const result = await pool.query(`SELECT c.id, u.id AS other_id, u.username AS other_username,
    m.body AS last_message, m.created_at AS last_at
    FROM conversations c
    JOIN conversation_members mine ON mine.conversation_id=c.id AND mine.user_id=$1
    JOIN conversation_members other ON other.conversation_id=c.id AND other.user_id<>$1
    JOIN users u ON u.id=other.user_id
    LEFT JOIN LATERAL (SELECT body,created_at FROM messages WHERE conversation_id=c.id ORDER BY id DESC LIMIT 1) m ON TRUE
    ORDER BY COALESCE(m.created_at,c.created_at) DESC`, [uid]);
  res.json({ conversations: result.rows });
});
app.post('/api/conversations', requireAuth, async (req, res) => {
  const targetName = String(req.body.username || '').trim().toLowerCase();
  const uid = req.session.user.id;
  const target = await pool.query('SELECT id,username FROM users WHERE username=$1', [targetName]);
  if (!target.rows[0]) return res.status(404).json({ error: 'User not found.' });
  const tid = target.rows[0].id;
  if (tid === uid) return res.status(400).json({ error: 'You cannot start a chat with yourself.' });
  const existing = await pool.query(`SELECT c.id FROM conversations c
    JOIN conversation_members a ON a.conversation_id=c.id AND a.user_id=$1
    JOIN conversation_members b ON b.conversation_id=c.id AND b.user_id=$2 LIMIT 1`, [uid, tid]);
  if (existing.rows[0]) return res.json({ conversationId: existing.rows[0].id });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const c = await client.query('INSERT INTO conversations DEFAULT VALUES RETURNING id');
    const cid = c.rows[0].id;
    await client.query('INSERT INTO conversation_members(conversation_id,user_id) VALUES($1,$2),($1,$3)', [cid, uid, tid]);
    await client.query('COMMIT');
    res.json({ conversationId: cid });
  } catch (e) { await client.query('ROLLBACK'); console.error(e); res.status(500).json({ error: 'Could not start chat.' }); }
  finally { client.release(); }
});
app.get('/api/conversations/:id/messages', requireAuth, async (req, res) => {
  const cid = Number(req.params.id);
  const check = await pool.query('SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2', [cid, req.session.user.id]);
  if (!check.rowCount) return res.status(403).json({ error: 'Not a member of this chat.' });
  const result = await pool.query(`SELECT m.id,m.body,m.created_at,u.username,sender_id FROM messages m JOIN users u ON u.id=m.sender_id
    WHERE m.conversation_id=$1 ORDER BY m.id DESC LIMIT 100`, [cid]);
  res.json({ messages: result.rows.reverse() });
});

const onlineUsers = new Map();
const socketAuth = (socket, next) => sessionMiddleware(socket.request, {}, next);
io.use((socket, next) => sessionMiddleware(socket.request, {}, next));
io.use((socket, next) => {
  const user = socket.request.session?.user;
  if (!user) return next(new Error('Not signed in'));
  socket.user = user;
  next();
});
io.on('connection', socket => {
  const user = socket.user;
  onlineUsers.set(user.id, (onlineUsers.get(user.id) || 0) + 1);
  socket.join(`user:${user.id}`);
  socket.emit('presence', [...onlineUsers.keys()]);
  io.emit('presence', [...onlineUsers.keys()]);
  socket.on('join-chat', async conversationId => {
    const cid = Number(conversationId);
    if (!Number.isInteger(cid)) return;
    const result = await pool.query('SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2', [cid, user.id]);
    if (result.rowCount) socket.join(`chat:${cid}`);
  });
  socket.on('send-message', async payload => {
    const cid = Number(payload?.conversationId);
    const body = String(payload?.body || '').trim();
    if (!body || body.length > 2000 || !Number.isInteger(cid)) return;
    const member = await pool.query('SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2', [cid, user.id]);
    if (!member.rowCount) return;
    const result = await pool.query('INSERT INTO messages(conversation_id,sender_id,body) VALUES($1,$2,$3) RETURNING id,body,created_at', [cid, user.id, body]);
    io.to(`chat:${cid}`).emit('new-message', { ...result.rows[0], username: user.username, sender_id: user.id });
  });
  socket.on('disconnect', () => {
    const count = (onlineUsers.get(user.id) || 1) - 1;
    if (count <= 0) onlineUsers.delete(user.id); else onlineUsers.set(user.id, count);
    io.emit('presence', [...onlineUsers.keys()]);
  });
});
app.get('*', (req, res) => res.sendFile(__dirname + '/public/index.html'));
initDb().then(() => server.listen(process.env.PORT || 3000, () => console.log('Relay running on port ' + (process.env.PORT || 3000)))).catch(err => { console.error('DB setup failed:', err); process.exit(1); });
